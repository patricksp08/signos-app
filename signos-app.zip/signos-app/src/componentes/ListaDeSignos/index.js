import React from 'react';
import Titulo from '../Titulo';
import ItemLista from '../ItemLista';
import './estilo.css';

function ListaDeSignos() {
    return(
        <div>
            <Titulo />
            
            <div className="Lista">
                <ItemLista signo="Aquario" dataInicio="21/01" dataFim="19/02" imagem="assets/aquario.jpg" />
                <ItemLista signo="Peixes" dataInicio="20/02" dataFim="20/03" imagem="assets/peixes.jpg" />
                <ItemLista signo="Aries" dataInicio="21/03" dataFim="20/04" imagem="assets/aries.jpg" />
                <ItemLista signo="Touro" dataInicio="21/04" dataFim="21/05" imagem="assets/touro.jpg" />
                <ItemLista signo="Gêmeos" dataInicio="21/05" dataFim="21/06" imagem="assets/gemeos.jpg" />
                <ItemLista signo="Câncer" dataInicio="22/06" dataFim="23/07" imagem="assets/cancer.jpg" />
                <ItemLista signo="Leão" dataInicio="24/07" dataFim="23/08" imagem="assets/leao.jpg" />
                <ItemLista signo="Virgem" dataInicio="24/08" dataFim="23/09" imagem="assets/virgem.jpg" />
                <ItemLista signo="Libra" dataInicio="24/09" dataFim="23/10" imagem="assets/libra.jpg" />
                <ItemLista signo="Escorpião" dataInicio="24/10" dataFim="23/11" imagem="assets/escorpiao.jpg" />
                <ItemLista signo="Sagitario" dataInicio="24/11" dataFim="23/12" imagem="assets/sagitario.jpg" />
                <ItemLista signo="Capricornio" dataInicio="24/12" dataFim="20/01" imagem="assets/capricornio.jpg" />
            </div>
        </div>
    )
}

export default ListaDeSignos;