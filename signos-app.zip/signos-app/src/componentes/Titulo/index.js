import React from 'react';
import './estilo.css';

function Titulo() {
    return(
        <div className="box">
            <p className="texto">Baralho dos Signos</p>
        </div>
    )
}
export default Titulo;
