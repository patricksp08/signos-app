import React from 'react'
import ListaDeSignos from './componentes/ListaDeSignos'

function App() {
  return(
    <ListaDeSignos />
  )
}

export default App;